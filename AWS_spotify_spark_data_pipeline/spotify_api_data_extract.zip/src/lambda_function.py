
import json
import spotipy
from spotipy.oauth2 import SpotifyClientCredentials
import os
from datetime import datetime
import boto3

def lambda_handler(event, context):
    client_id = os.environ.get('client_id')
    client_secret = os.environ.get('client_secret')
    
    client_credentials_manager = SpotifyClientCredentials(client_id = client_id, client_secret=client_secret)
    spApi = spotipy.Spotify(client_credentials_manager = client_credentials_manager)
    
    playlist_link = "https://open.spotify.com/playlist/37i9dQZEVXbNG2KDcFcKOF"
    playlist_uri = playlist_link.split("/")[-1].split('?')[0]
    
    spotify_data = spApi.playlist_tracks(playlist_uri)
    
    client = boto3.client('s3')
    
    filename = "spotify_raw_data_" + str(datetime.now()) + '.json'
    client.put_object(Bucket="spotify-etl-project-tqx", Key="raw_data/to_processed/"+ filename, Body=json.dumps(spotify_data))
    
    
    
    
    # album_list = []

    # for row in spotify_data['items']:
    #     album_id = row['track']['album']['id']
    #     album_name = row['track']['album']['name']
    #     album_release_date = row['track']['album']['release_date']
    #     album_total_tracks = row['track']['album']['total_tracks']
    #     album_url = row["track"]["album"]['external_urls']['spotify']
    #     album_element = { 'album_id': album_id, 'name': album_name, 'release_date': album_release_date, 'total_tracks': album_total_tracks, 'url': album_url}
    #     album_list.append(album_element)
        
    # artist_info = []
    # artist_list = []
    # for row in spotify_data['items']:
    #     for key, value in row.items():
    #         if key == 'track':
    #             for artist in value['artists']:
    #                 artists_info = spotipy.artist(artist['id'])
    #                 artist_dict = {"artist_id": artist['id'], "artist_name": artist['name'], 'artist_genres': ', '.join(artists_info['genres']), 
    #                               'followers': artists_info['followers']['total'], 'popularity': artists_info['popularity'], 'external_uri': artist['href']}
    #                 artist_list.append(artist_dict)
                    
    # song_list = []
    # for row in spotify_data['items']:
    #     artist_ids = []
    #     song_id = row['track']['id']
    #     song_name = row['track']['name']
    #     song_duration = row['track']['duration_ms']
    #     song_url = row['track']['external_urls']['spotify']
    #     song_popularity = row['track']['popularity']
    #     song_added = row['added_at']
    #     album_id = row['track']['album']['id']
    #     if len(row['track']['artists']) > 1:
    #         for artist in row['track']['artists']:
    #             artist_ids.append(artist['id'])
    #     else: 
    #         artist_ids.append(row['track']['artists'][0]['id'])
    #     song_element = { "song_id": song_id, "song_name": song_name, "song_duration": song_duration, "song_url": song_url,
    #                   "song_popularity": song_popularity, "song_added": song_added, "album_id": album_id, "artist_id": ', '.join(artist_ids)}
    #     song_list.append(song_element)
        
    
    # album_df = pd.DataFrame.from_dict(album_list)
    # album_df['release_date'] = pd.to_datetime(album_df['release_date'], format='mixed')
    # album_df = album_df.drop_duplicates(subset=['album_id'])
    
    # artist_df = pd.DataFrame.from_dict(artist_list)
    # artist_df.drop_duplicates(subset=['artist_id'])
    
    # song_df = pd.DataFrame.from_dict(song_list)
    # song_df.drop_duplicates(subset=['song_id'])
    # song_df['song_added'] = pd.to_datetime(song_df['song_added']).dt.date
    # song_df['song_added'] = pd.to_datetime(song_df['song_added'])
    